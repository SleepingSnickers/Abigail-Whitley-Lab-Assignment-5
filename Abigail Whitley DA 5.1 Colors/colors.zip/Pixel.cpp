#include "Pixel.h"

Pixel::Pixel() {
	X = 0;
	Y = 0;
	red = 0;
	green = 0;
	blue = 0;
	img = ' ';
}

Pixel::Pixel(int X, int Y, int red, int green, int blue, char img) {
	this->X = X;
	this->Y = Y;
	this->red = red;
	this->green = green;
	this->blue = blue;
	this->img = img;
}

int Pixel::getX() const { 
	return X;
}

int Pixel::getY() const { 
	return Y; 
}

int Pixel::getRed() const { 
	return red; 
}

int Pixel::getGreen() const { 
	return green; 
}

int Pixel::getBlue() const { 
	return blue;
}

char Pixel::getImg() const { 
	return img;
}

void Pixel::setX(int X) {
	this->X = X;
}

void Pixel::setY(int Y) {
	this->Y = Y;
}

void Pixel::setRed(int red) { 
	this->red = red;
}

void Pixel::setGreen(int green) { 
	this->green = green;
}

void Pixel::setBlue(int blue) { 
	this->blue = blue;
}

void Pixel::setImg(char img) { 
	this->img = img;
}

ostream& operator<< (ostream& out, const Pixel& pix) {
	out << pix.img << endl;
	return out;
}