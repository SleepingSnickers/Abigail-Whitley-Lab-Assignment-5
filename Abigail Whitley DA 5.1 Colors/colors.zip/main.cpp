#include "PicReader.h"
#include <iostream>
#include <vector>

int main() {
    std::vector<Pixel> pixels = PicReader::readPic("colors.txt");

    for (const Pixel& p : pixels) {
        std::cout << p;
    }

    return 0;
}